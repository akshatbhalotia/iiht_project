package com.javasampleapproach.springrest.mysql.model;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.*;


@Entity
@Table(name = "Mentor_Calendar")
public class MentorCalendar implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
//link to Mentor.java
    
//link to mentorSkill.java Mid
    @Column(name="mentor_id")
    private Long mentor_id;
    
 //unique courses must have unique mid and folowing all the entity
    @Column(name="start_time")
    private String start_time ;

    @Column(name="end_time")
    private String end_time ;

    @Column(name="start_date")
    private String start_date ;

    @Column(name="end_date")
    private String end_date ;

    public Long getId() {
		return id;
	}


	public Long getMentor_id() {
		return mentor_id;
	}


	public void setMentor_id(Long mentor_id) {
		this.mentor_id = mentor_id;
	}



	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public MentorCalendar(Long mentor_id, String start_time, String end_time, String start_date, String end_date) {
		super();
		this.mentor_id = mentor_id;
		this.start_time = start_time;
		this.end_time = end_time;
		this.start_date = start_date;
		this.end_date = end_date;
	}

	public MentorCalendar() {
		super();
		// TODO Auto-generated constructor stub
	}

	
    
    

}
