package com.javasampleapproach.springrest.mysql.model;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.*;


@Entity
@Table(name = "Technology")
public class Technology implements Serializable {
    


	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
//link to MentorSkill.java
    
    
 //unique courses must have unique mid and folowing all the entity
   
    @Column(name = "technology_name")
    private String name ;
    
    
    @Column(name = "toc")
    private String toc ;
    
    
    @Column(name = "fees")
    private Double fees ;
    
   
    @Column(name = "duration")
    private Double duration ;
    
   
    @Column(name = "prerequites")
    private String prerequites ;
    
    public String Name() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getToc() {
		return toc;
	}


	public void setToc(String toc) {
		this.toc = toc;
	}


	public Double getFees() {
		return fees;
	}


	public void setFees(Double fees) {
		this.fees = fees;
	}


	public Double getDuration() {
		return duration;
	}


	public void setDuration(Double duration) {
		this.duration = duration;
	}


	public String getPrerequites() {
		return prerequites;
	}
	
	public Long getId() {
		return id;
	}


	public void setPrerequites(String prerequites) {
		this.prerequites = prerequites;
	}


	public Technology(String name, String toc, Double fees, Double duration, String prerequites) {
		super();
		this.name = name;
		this.toc = toc;
		this.fees = fees;
		this.duration = duration;
		this.prerequites = prerequites;
	}


	public Technology() {
		super();
		// TODO Auto-generated constructor stub
	}
    


}
