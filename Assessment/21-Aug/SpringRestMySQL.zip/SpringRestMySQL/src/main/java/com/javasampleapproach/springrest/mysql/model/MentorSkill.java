package com.javasampleapproach.springrest.mysql.model;

import javax.persistence.*;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.*;


@Entity
@Table(name = "Mentor_Skill")
public class MentorSkill implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
//link to Mentor.java
    
    @Column(name="mentor_id")
    private Long mentor_id;
 //unique courses must have unique mid and folowing all the entity
    
    //import sid from technology.java
    @Column(name="skill_id")
    private Long skill_id;
    
    @Column(name="self_rating")
    private Double self_rating;

    @Column(name="year_of_experience")
    private Integer yoe;

    @Column(name="trainings_delivered")
    private Integer trainings_delivered ;
    
    @Column(name="facilities_offered")
    private String facilities_offered;
    
    public Long getId() {
		return id;
	}

	public Long getMentor_id() {
		return mentor_id;
	}

	public void setMentor_id(Long mentor_id) {
		this.mentor_id = mentor_id;
	}

	public Long getSkill_id() {
		return skill_id;
	}

	public void setSkill_id(Long skill_id) {
		this.skill_id = skill_id;
	}

	public Double getSelf_rating() {
		return self_rating;
	}

	public void setSelf_rating(Double self_rating) {
		this.self_rating = self_rating;
	}

	public Integer getYoe() {
		return yoe;
	}

	public void setYoe(Integer yoe) {
		this.yoe = yoe;
	}

	public Integer getTrainings_delivered() {
		return trainings_delivered;
	}

	public void setTrainings_delivered(Integer trainings_delivered) {
		this.trainings_delivered = trainings_delivered;
	}

	public String getFacilities_offered() {
		return facilities_offered;
	}

	public void setFacilities_offered(String facilities_offered) {
		this.facilities_offered = facilities_offered;
	}

	public MentorSkill() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MentorSkill(Long mentor_id, Long skill_id, Double self_rating, Integer yoe, Integer trainings_delivered,
			String facilities_offered) {
		super();
		this.mentor_id = mentor_id;
		this.skill_id = skill_id;
		this.self_rating = self_rating;
		this.yoe = yoe;
		this.trainings_delivered = trainings_delivered;
		this.facilities_offered = facilities_offered;
	}



}
